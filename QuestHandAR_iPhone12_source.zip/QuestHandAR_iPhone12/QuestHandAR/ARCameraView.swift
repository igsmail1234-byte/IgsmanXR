import SwiftUI
import ARKit
import SceneKit

struct ARCameraView: UIViewRepresentable {
    @ObservedObject var controller: ARHandController

    func makeUIView(context: Context) -> ARSCNView {
        let view = ARSCNView(frame: .zero)
        view.automaticallyUpdatesLighting = true
        view.scene = SCNScene()
        view.delegate = context.coordinator
        controller.attach(view: view)
        return view
    }

    func updateUIView(_ uiView: ARSCNView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(controller: controller)
    }

    final class Coordinator: NSObject, ARSCNViewDelegate {
        private let controller: ARHandController
        init(controller: ARHandController) { self.controller = controller }
    }
}
