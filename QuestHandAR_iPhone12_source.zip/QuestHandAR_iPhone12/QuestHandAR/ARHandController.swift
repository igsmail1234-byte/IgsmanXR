import Foundation
import Combine
import AVFoundation
import ARKit
import Vision
import SceneKit
import UIKit

final class ARHandController: NSObject, ObservableObject, ARSessionDelegate {
    @Published var handPoints: [CGPoint] = []
    @Published var handDetected = false
    @Published var isPinching = false
    @Published var cameraReady = false
    @Published var status = "Starting camera…"

    private weak var arView: ARSCNView?
    private let visionQueue = DispatchQueue(label: "questhand.vision.queue")
    private var isProcessingFrame = false
    private var lastPinchTime = Date.distantPast
    private var menuNodesAdded = false

    func attach(view: ARSCNView) {
        arView = view
        view.session.delegate = self
        addFloatingMenu(to: view)
    }

    func start() {
        guard ARWorldTrackingConfiguration.isSupported else {
            DispatchQueue.main.async {
                self.status = "ARKit is not supported on this device"
                self.cameraReady = false
            }
            return
        }

        AVCameraPermission.request { [weak self] allowed in
            guard let self else { return }
            DispatchQueue.main.async {
                guard allowed else {
                    self.status = "Camera permission required"
                    return
                }
                guard let view = self.arView else { return }
                let configuration = ARWorldTrackingConfiguration()
                configuration.worldAlignment = .gravity
                configuration.planeDetection = [.horizontal]
                view.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
                self.cameraReady = true
                self.status = "Camera active"
            }
        }
    }

    func stop() {
        arView?.session.pause()
    }

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard !isProcessingFrame else { return }
        isProcessingFrame = true
        let pixelBuffer = frame.capturedImage

        visionQueue.async { [weak self] in
            defer { self?.isProcessingFrame = false }
            guard let self else { return }

            let request = VNDetectHumanHandPoseRequest()
            request.maximumHandCount = 1
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer,
                                                orientation: .right,
                                                options: [:])
            do {
                try handler.perform([request])
                guard let observation = request.results?.first else {
                    DispatchQueue.main.async {
                        self.handDetected = false
                        self.handPoints = []
                        self.isPinching = false
                        self.status = self.cameraReady ? "Show your hand to the camera" : self.status
                    }
                    return
                }

                let names: [VNHumanHandPoseObservation.JointName] = [
                    .wrist,
                    .thumbCMC, .thumbMP, .thumbIP, .thumbTip,
                    .indexMCP, .indexPIP, .indexDIP, .indexTip,
                    .middleMCP, .middlePIP, .middleDIP, .middleTip,
                    .ringMCP, .ringPIP, .ringDIP, .ringTip,
                    .littleMCP, .littlePIP, .littleDIP, .littleTip
                ]
                var points: [CGPoint] = []
                for name in names {
                    if let point = try? observation.recognizedPoint(name), point.confidence > 0.25 {
                        points.append(CGPoint(x: point.location.x, y: point.location.y))
                    }
                }

                let thumb = try? observation.recognizedPoint(.thumbTip)
                let index = try? observation.recognizedPoint(.indexTip)
                let pinch = {
                    guard let thumb, let index, thumb.confidence > 0.25, index.confidence > 0.25 else { return false }
                    let dx = thumb.location.x - index.location.x
                    let dy = thumb.location.y - index.location.y
                    return sqrt(dx * dx + dy * dy) < 0.055
                }()

                DispatchQueue.main.async {
                    self.handDetected = true
                    self.handPoints = points
                    self.isPinching = pinch
                    self.status = "Hand tracking active"
                }
            } catch {
                DispatchQueue.main.async {
                    self.status = "Hand tracking unavailable"
                }
            }
        }
    }

    private func addFloatingMenu(to view: ARSCNView) {
        guard !menuNodesAdded else { return }
        menuNodesAdded = true

        // A lightweight 3D floating panel placed in front of the starting camera.
        let panel = SCNNode(geometry: SCNPlane(width: 0.72, height: 0.36))
        let material = SCNMaterial()
        material.diffuse.contents = UIColor(red: 0.035, green: 0.055, blue: 0.09, alpha: 0.82)
        material.isDoubleSided = true
        panel.geometry?.materials = [material]
        panel.position = SCNVector3(0, -0.10, -1.15)
        view.scene.rootNode.addChildNode(panel)

        let title = makeTextNode("QUEST SPACE", size: 0.045, color: UIColor.cyan)
        title.position = SCNVector3(-0.29, 0.105, 0.008)
        panel.addChildNode(title)

        let labels = ["HOME", "EXPLORE", "HANDS", "SETTINGS"]
        for (index, label) in labels.enumerated() {
            let x = Float(-0.255 + Double(index) * 0.17)
            let tile = SCNNode(geometry: SCNPlane(width: 0.145, height: 0.13))
            let tileMaterial = SCNMaterial()
            tileMaterial.diffuse.contents = UIColor(white: 1, alpha: 0.10)
            tileMaterial.isDoubleSided = true
            tile.geometry?.materials = [tileMaterial]
            tile.position = SCNVector3(x, -0.045, 0.006)
            panel.addChildNode(tile)

            let text = makeTextNode(label, size: 0.017, color: UIColor.white)
            text.position = SCNVector3(-0.048, -0.008, 0.006)
            tile.addChildNode(text)
        }
    }

    private func makeTextNode(_ string: String, size: CGFloat, color: UIColor) -> SCNNode {
        let text = SCNText(string: string, extrusionDepth: 0.001)
        text.font = UIFont.systemFont(ofSize: size * 100, weight: .semibold)
        text.flatness = 0.2
        text.firstMaterial?.diffuse.contents = color
        let node = SCNNode(geometry: text)
        node.scale = SCNVector3(0.01, 0.01, 0.01)
        return node
    }
}

private enum AVCameraPermission {
    static func request(completion: @escaping (Bool) -> Void) {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            completion(true)
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video, completionHandler: completion)
        default:
            completion(false)
        }
    }
}
