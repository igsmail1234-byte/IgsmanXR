import SwiftUI
import ARKit
import Vision

struct ContentView: View {
    @StateObject private var controller = ARHandController()
    @State private var menuVisible = true
    @State private var selected = "HOME"

    var body: some View {
        ZStack {
            ARCameraView(controller: controller)
                .ignoresSafeArea()

            // Vision hand landmarks are drawn over the live AR camera.
            HandSkeletonOverlay(points: controller.handPoints)
                .ignoresSafeArea()
                .allowsHitTesting(false)

            VStack(spacing: 12) {
                HStack {
                    Circle()
                        .fill(controller.cameraReady ? Color.green : Color.orange)
                        .frame(width: 8, height: 8)
                    Text(controller.status)
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                    Spacer()
                    Button {
                        menuVisible.toggle()
                    } label: {
                        Image(systemName: menuVisible ? "eye.slash" : "eye")
                            .font(.system(size: 16, weight: .semibold))
                            .frame(width: 42, height: 42)
                            .background(.ultraThinMaterial, in: Circle())
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)

                Spacer()

                if menuVisible {
                    VStack(alignment: .leading, spacing: 14) {
                        HStack(spacing: 10) {
                            Image(systemName: "visionpro")
                                .font(.system(size: 22, weight: .medium))
                                .foregroundStyle(Color.cyan)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("QUEST SPACE")
                                    .font(.system(size: 18, weight: .bold, design: .rounded))
                                    .tracking(1.6)
                                Text("Mixed Reality • Hand Tracking")
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundStyle(.white.opacity(0.65))
                            }
                            Spacer()
                            Text("BETA")
                                .font(.system(size: 10, weight: .bold))
                                .tracking(1)
                                .padding(.horizontal, 9)
                                .padding(.vertical, 5)
                                .background(Color.cyan.opacity(0.18), in: Capsule())
                        }

                        HStack(spacing: 10) {
                            MenuTile(title: "Home", symbol: "house.fill", isSelected: selected == "HOME") {
                                selected = "HOME"
                            }
                            MenuTile(title: "Explore", symbol: "globe", isSelected: selected == "EXPLORE") {
                                selected = "EXPLORE"
                            }
                            MenuTile(title: "Hands", symbol: "hand.raised.fill", isSelected: selected == "HANDS") {
                                selected = "HANDS"
                            }
                            MenuTile(title: "Settings", symbol: "gearshape.fill", isSelected: selected == "SETTINGS") {
                                selected = "SETTINGS"
                            }
                        }

                        HStack(spacing: 8) {
                            Image(systemName: controller.isPinching ? "hand.tap.fill" : "hand.point.up.left.fill")
                                .foregroundStyle(controller.isPinching ? .green : .cyan)
                            Text(controller.isPinching
                                 ? "Pinch detected"
                                 : (controller.handDetected ? "Hand detected — pinch thumb and index" : "Show your hand to the camera"))
                                .font(.system(size: 12, weight: .medium))
                                .foregroundStyle(.white.opacity(0.82))
                            Spacer()
                        }
                        .padding(.top, 2)
                    }
                    .padding(18)
                    .background {
                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                            .fill(.ultraThinMaterial)
                            .overlay {
                                RoundedRectangle(cornerRadius: 25, style: .continuous)
                                    .stroke(.white.opacity(0.18), lineWidth: 1)
                            }
                    }
                    .shadow(color: .black.opacity(0.3), radius: 24, y: 10)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 28)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.86), value: menuVisible)
        .onAppear { controller.start() }
        .onDisappear { controller.stop() }
    }
}

private struct MenuTile: View {
    let title: String
    let symbol: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 9) {
                Image(systemName: symbol)
                    .font(.system(size: 19, weight: .semibold))
                    .frame(height: 24)
                Text(title)
                    .font(.system(size: 11, weight: .semibold))
            }
            .foregroundStyle(isSelected ? Color.cyan : Color.white.opacity(0.88))
            .frame(maxWidth: .infinity)
            .frame(height: 76)
            .background(isSelected ? Color.cyan.opacity(0.18) : Color.white.opacity(0.06),
                        in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(isSelected ? Color.cyan.opacity(0.7) : Color.white.opacity(0.10), lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }
}

private struct HandSkeletonOverlay: View {
    let points: [CGPoint]

    var body: some View {
        GeometryReader { geometry in
            Canvas { context, size in
                guard !points.isEmpty else { return }
                let valid = points.filter { $0.x.isFinite && $0.y.isFinite }
                for point in valid {
                    let rect = CGRect(x: point.x * size.width - 4,
                                      y: (1 - point.y) * size.height - 4,
                                      width: 8, height: 8)
                    context.fill(Path(ellipseIn: rect), with: .color(.cyan))
                }
            }
        }
    }
}
