# Quest Hand AR — iPhone 12

Projekt startowy SwiftUI + ARKit + Vision. Pokazuje obraz z tylnej kamery, śledzi punkty dłoni przez Vision i prezentuje menu inspirowane interfejsem mixed reality.

## Ważne ograniczenia

- To są źródła projektu, a nie gotowy ani podpisany plik IPA.
- Projekt trzeba skompilować w Xcode na macOS. Sam Windows 11 nie uruchomi Xcode.
- eSign podpisuje istniejący plik IPA; nie kompiluje źródeł.
- W tej wersji menu ma zarówno panel 3D umieszczony w scenie AR, jak i wygodne nakładkowe menu ekranowe. Wykrywanie gestu „pinch” jest pokazywane jako status; wybieranie kafelków gestem wymaga dalszego dopracowania i testów na urządzeniu.
- Kamera i hand tracking wymagają zgody użytkownika.

## Pliki

- `QuestHandAR/QuestHandARApp.swift` — punkt wejścia aplikacji
- `QuestHandAR/ContentView.swift` — menu i wizualizacja punktów dłoni
- `QuestHandAR/ARCameraView.swift` — widok ARKit
- `QuestHandAR/ARHandController.swift` — sesja ARKit oraz analiza Vision
- `QuestHandAR/Info.plist` — opis aplikacji i zgoda na kamerę

## Kompilacja

1. Przenieś folder `QuestHandAR` na komputer Mac z Xcode.
2. Otwórz Xcode i wybierz **File → New → Project → iOS → App**.
3. Nazwa: `QuestHandAR`; Interface: **SwiftUI**; Language: **Swift**.
4. Usuń przykładowy `ContentView.swift` i plik aplikacji utworzony przez szablon albo zastąp ich zawartość plikami z tego projektu.
5. Dodaj `ARCameraView.swift` i `ARHandController.swift` do targetu aplikacji (zaznacz **Copy items if needed**).
6. W **Target → Info** dodaj `Privacy - Camera Usage Description` z tekstem: `Quest Hand AR uses the camera for augmented reality and hand tracking.`
7. W **Target → General → Minimum Deployments** wybierz iOS 16.0 lub nowszy.
8. W **Signing & Capabilities** ustaw unikalny Bundle Identifier, np. `com.twojlogin.QuestHandAR`, i wybierz swój zespół Apple.
9. Podłącz iPhone 12, zaakceptuj zaufanie do komputera i włącz Developer Mode, jeśli iOS o to poprosi.
10. Wybierz iPhone jako urządzenie uruchomieniowe i naciśnij **Run**.

## Eksport IPA

1. W Xcode wybierz **Any iOS Device (arm64)** jako miejsce docelowe.
2. Wybierz **Product → Archive**.
3. W Organizerze wybierz archiwum i **Distribute App**.
4. Wybierz metodę dystrybucji odpowiednią dla Twojego konta i urządzeń. Xcode utworzy plik IPA tylko wtedy, gdy konfiguracja podpisywania na to pozwala.
5. Jeśli masz poprawny IPA i certyfikat/profil zgodny z instalacją, możesz użyć eSign do podpisania go. Nie udostępniaj nikomu hasła Apple ID ani prywatnych kluczy certyfikatów.

## Uwagi techniczne

Kod używa `VNDetectHumanHandPoseRequest` i `ARWorldTrackingConfiguration`. Orientacja klatek z kamery i współrzędne punktów Vision mogą wymagać korekty zależnie od orientacji telefonu i testów. To projekt bazowy do uruchomienia i dalszego dopracowania, nie certyfikowana aplikacja produkcyjna.
