@echo off
cd /d "%~dp0"
echo.
echo META QUEST 3 AR WEB
echo.
echo Uruchamiam serwer lokalny na porcie 8000...
echo UWAGA: adres http:// nie pozwoli iPhone Safari uzywac kamery.
echo Do testu na iPhonie potrzebny jest adres HTTPS (np. hosting HTTPS).
echo.
py -3.10 -m http.server 8000
pause
