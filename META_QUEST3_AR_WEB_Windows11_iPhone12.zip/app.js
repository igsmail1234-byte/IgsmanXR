import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { FilesetResolver, HandLandmarker } from 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';

const video = document.querySelector('#camera');
const canvas = document.querySelector('#three-canvas');
const startButton = document.querySelector('#startButton');
const trackingStatus = document.querySelector('#trackingStatus');
const handStatus = document.querySelector('#handStatus');
const welcome = document.querySelector('.welcome');
const toastEl = document.querySelector('#toast');

let renderer, scene, camera3D, menuGroup, handLandmarker;
let stream = null, lastVideoTime = -1, lastPinchAt = 0;
let started = false, orientationEnabled = false;
let yaw = 0, pitch = 0, baseYaw = 0, baseBeta = 0, baseGamma = 0;
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const clickable = [];

function toast(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 1900);
}

function setupThree() {
  renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  scene = new THREE.Scene();
  camera3D = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, 0.01, 50);
  camera3D.position.set(0, 0, 0);
  scene.add(new THREE.HemisphereLight(0xbbeeff, 0x17243a, 2.0));
  const key = new THREE.DirectionalLight(0xffffff, 2.2);
  key.position.set(-2, 3, 4); scene.add(key);
  buildMenu();
  window.addEventListener('resize', onResize);
  animate();
}

function roundedPanel(width, height, color, opacity=0.82) {
  const shape = new THREE.Shape();
  const r = 0.055, x=-width/2, y=-height/2;
  shape.moveTo(x+r,y); shape.lineTo(x+width-r,y); shape.quadraticCurveTo(x+width,y,x+width,y+r);
  shape.lineTo(x+width,y+height-r); shape.quadraticCurveTo(x+width,y+height,x+width-r,y+height);
  shape.lineTo(x+r,y+height); shape.quadraticCurveTo(x,y+height,x,y+height-r);
  shape.lineTo(x,y+r); shape.quadraticCurveTo(x,y,x+r,y);
  const geometry = new THREE.ShapeGeometry(shape);
  const material = new THREE.MeshPhysicalMaterial({color, transparent:true, opacity, roughness:.32, metalness:.16, side:THREE.DoubleSide});
  return new THREE.Mesh(geometry, material);
}

function makeText(text, size, color='#ffffff') {
  // Canvas texture keeps labels crisp without external font geometry.
  const c = document.createElement('canvas'); c.width=1024; c.height=256;
  const ctx = c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height);
  ctx.font = `600 ${Math.round(size*900)}px Arial`;
  ctx.fillStyle = color; ctx.textBaseline='middle'; ctx.fillText(text, 20, 128);
  const texture = new THREE.CanvasTexture(c); texture.colorSpace=THREE.SRGBColorSpace;
  const mat = new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false});
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size*4, size),mat);
  return mesh;
}

function buildMenu() {
  menuGroup = new THREE.Group();
  menuGroup.position.set(0, -0.02, -1.65);
  scene.add(menuGroup);

  const panel = roundedPanel(1.18,.78,0x0a1930,.84);
  panel.position.z=-.015; menuGroup.add(panel);

  const accent = new THREE.Mesh(new THREE.BoxGeometry(.025,.53,.012),new THREE.MeshBasicMaterial({color:0x70e5ff}));
  accent.position.set(-.535,-.005,.006); menuGroup.add(accent);

  const title=makeText('META QUEST',.075); title.position.set(-.47,.265,.015); menuGroup.add(title);
  const subtitle=makeText('UNIVERSAL MENU  /  AR EXPERIENCE',.025,'#83eaff');
  subtitle.position.set(-.46,.195,.015); menuGroup.add(subtitle);

  const items=[
    {name:'HOME',icon:'⌂'},{name:'LIBRARY',icon:'▤'},{name:'STORE',icon:'＋'},
    {name:'BROWSER',icon:'◎'},{name:'SETTINGS',icon:'⚙'}
  ];
  items.forEach((item,i)=>{
    const x=-.43+i*.215;
    const tile=roundedPanel(.185,.245,0x183451,.96);
    tile.position.set(x,-.025,.02); tile.userData={action:item.name};
    menuGroup.add(tile); clickable.push(tile);
    const icon=makeText(item.icon,.10,'#eafaff'); icon.position.set(x-.06,.005,.03); menuGroup.add(icon);
    const label=makeText(item.name,.022,'#d5eaff'); label.position.set(x-.075,-.105,.03); menuGroup.add(label);
  });
  const foot=makeText('PINCH TO SELECT  •  MOVE PHONE TO LOOK AROUND',.022,'#7de7ff');
  foot.position.set(-.42,-.30,.02); menuGroup.add(foot);
}

function onResize(){
  if(!renderer)return;
  camera3D.aspect=innerWidth/innerHeight; camera3D.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
}

function animate(){
  requestAnimationFrame(animate);
  if(menuGroup){
    // Orientation rotates the virtual camera: this is not ARKit/world tracking.
    camera3D.rotation.order='YXZ';
    camera3D.rotation.y=yaw;
    camera3D.rotation.x=pitch;
  }
  renderer?.render(scene,camera3D);
}

async function enableOrientation(){
  try{
    if(typeof DeviceOrientationEvent!=='undefined' && typeof DeviceOrientationEvent.requestPermission==='function'){
      const permission=await DeviceOrientationEvent.requestPermission();
      if(permission!=='granted')return;
    }
    window.addEventListener('deviceorientation', onOrientation, true);
    orientationEnabled=true;
  }catch(e){ console.warn('Orientation permission:',e); }
}
function onOrientation(e){
  if(e.alpha==null)return;
  if(baseYaw===0 && baseBeta===0 && baseGamma===0){baseYaw=e.alpha;baseBeta=e.beta||0;baseGamma=e.gamma||0;}
  const alpha=(e.alpha-baseYaw)*Math.PI/180;
  const beta=((e.beta||0)-baseBeta)*Math.PI/180;
  const gamma=((e.gamma||0)-baseGamma)*Math.PI/180;
  yaw = THREE.MathUtils.clamp(-alpha,-1.35,1.35);
  pitch = THREE.MathUtils.clamp(-beta*.55 + gamma*.25,-.8,.8);
}

async function startCamera(){
  if(!navigator.mediaDevices?.getUserMedia)throw new Error('Przeglądarka nie udostępnia kamery. Użyj Safari i HTTPS.');
  stream=await navigator.mediaDevices.getUserMedia({
    audio:false,
    video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30}}
  });
  video.srcObject=stream;
  await video.play();
}

async function startHandTracking(){
  const vision=await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm');
  handLandmarker=await HandLandmarker.createFromOptions(vision,{
    baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',delegate:'GPU'},
    runningMode:'VIDEO',numHands:2
  });
}

function screenPointFromHand(point){
  pointer.x=point.x*2-1;
  pointer.y=-(point.y*2-1);
  raycaster.setFromCamera(pointer,camera3D);
  const hits=raycaster.intersectObjects(clickable,false);
  if(hits.length){
    const obj=hits[0].object;
    const action=obj.userData.action;
    if(action){
      obj.material.color.setHex(0x28799a);
      toast(`${action} · SELECTED`);
      setTimeout(()=>obj.material.color.setHex(0x183451),250);
    }
  }
}

function processHands(){
  if(!handLandmarker || video.readyState<2)return;
  if(video.currentTime===lastVideoTime)return;
  lastVideoTime=video.currentTime;
  const result=handLandmarker.detectForVideo(video,performance.now());
  if(!result.landmarks?.length){
    handStatus.textContent='HAND TRACKING · NO HAND';
    return;
  }
  const hand=result.landmarks[0];
  const thumb=hand[4], index=hand[8];
  const distance=Math.hypot(thumb.x-index.x,thumb.y-index.y);
  const pinching=distance<.055;
  handStatus.textContent=pinching?'HAND TRACKING · PINCH':'HAND TRACKING · HAND DETECTED';
  if(pinching && performance.now()-lastPinchAt>650){
    lastPinchAt=performance.now();
    screenPointFromHand({x:(thumb.x+index.x)/2,y:(thumb.y+index.y)/2});
  }
  // Small visual cursor for fingertip.
  const cursor=hand[8];
  const cursorX=(cursor.x-.5)*.8;
  const cursorY=(.5-cursor.y)*.5;
  handCursor.position.set(cursorX,cursorY,-1.25);
  handCursor.visible=true;
}
const handCursor=new THREE.Mesh(new THREE.RingGeometry(.012,.018,24),new THREE.MeshBasicMaterial({color:0x79e4ff,transparent:true,opacity:.9}));
handCursor.visible=false;
if(!scene){ /* attached after scene creation below */ }

async function startExperience(){
  startButton.disabled=true; startButton.textContent='STARTING CAMERA…';
  try{
    await startCamera();
    if(!renderer)setupThree();
    scene.add(handCursor);
    await enableOrientation();
    trackingStatus.textContent=orientationEnabled?'ORIENTATION ACTIVE':'CAMERA ACTIVE';
    welcome.style.display='none';
    toast('CAMERA READY · INITIALIZING HAND TRACKING');
    await startHandTracking();
    handStatus.textContent='HAND TRACKING · READY';
    started=true;
    toast('QUEST AR READY');
    handLoop();
  }catch(error){
    console.error(error);
    startButton.disabled=false;
    startButton.innerHTML='TRY AGAIN <span>↗</span>';
    toast(error.message||'Nie udało się uruchomić aplikacji.');
    trackingStatus.textContent='SETUP REQUIRED';
  }
}
function handLoop(){
  if(!started)return;
  try{processHands();}catch(e){console.warn(e);}
  requestAnimationFrame(handLoop);
}
startButton.addEventListener('click',startExperience);
document.querySelector('#recenterButton').addEventListener('click',()=>{
  baseYaw=0;baseBeta=0;baseGamma=0;yaw=0;pitch=0;
  if(menuGroup){menuGroup.position.set(0,-.02,-1.65);}
  toast('VIEW RECENTERED');
});
if('serviceWorker' in navigator && location.protocol.startsWith('http')){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.warn));
}
