META QUEST 3 AR WEB – WINDOWS 11 + IPHONE 12
================================================

CO ZAWIERA
- index.html – ekran aplikacji
- style.css – wygląd futurystycznego interfejsu
- app.js – Three.js, kamera, orientacja telefonu i MediaPipe Hand Landmarker
- manifest.webmanifest – konfiguracja PWA
- sw.js – Service Worker / cache plików
- icons – ikony PWA
- start_server.bat – lokalny serwer testowy

WAŻNE OGRANICZENIA
1. To aplikacja webowa, nie natywne ARKit. Obrót telefonu steruje wirtualną kamerą, ale nie ma prawdziwego world tracking 6DOF (pozycja X/Y/Z zakotwiczona w świecie).
2. Hand tracking działa przez MediaPipe i tylną kamerę. Gest PINCH jest prototypowy.
3. iPhone Safari wymaga HTTPS lub localhost dla dostępu do kamery. Lokalny serwer HTTP na Windows nie wystarczy do otwarcia kamery z iPhone'a.
4. Do działania MediaPipe i Three.js potrzebny jest internet przy pierwszym uruchomieniu (biblioteki i model pobierane z CDN).
5. Aplikacja może być dodana do ekranu początkowego jako PWA po opublikowaniu pod HTTPS.

URUCHOMIENIE NA WINDOWS 11
1. Rozpakuj folder.
2. Zainstaluj Python 3.10 lub nowszy, jeśli nie masz.
3. Dwuklik start_server.bat.
4. Na komputerze otwórz http://localhost:8000 (podgląd; kamera na komputerze może działać).
5. Aby używać na iPhonie, opublikuj zawartość folderu na hostingu HTTPS, np. GitHub Pages:
   - utwórz repozytorium GitHub,
   - wrzuć wszystkie pliki i folder icons,
   - w Settings > Pages wybierz Deploy from a branch, gałąź main i folder /(root),
   - otwórz podany adres https://... na iPhonie w Safari.
   Uwaga: GitHub Pages jest statycznym hostingiem HTTPS, więc nie uruchamiaj tam pliku .bat.

INSTALACJA PWA NA IPHONE 12
1. Otwórz stronę HTTPS w Safari.
2. Kliknij Udostępnij.
3. Wybierz Dodaj do ekranu początkowego.
4. Uruchom ikonę Quest AR.
5. Kliknij START AR EXPERIENCE i zezwól na kamerę oraz ruch/orientację, jeśli Safari zapyta.

OBSŁUGA
- Trzymaj telefon pionowo i skieruj tylną kamerę na dłoń.
- Zapewnij dobre, równomierne oświetlenie.
- Złącz kciuk z palcem wskazującym (PINCH), gdy czubki palców znajdą się nad jednym z kafelków.
- RECENTER resetuje orientację widoku.

UWAGA O MENU
Menu jest renderowane jako obiekt Three.js w wirtualnej przestrzeni, a obrót telefonu zmienia widok. Bez WebXR/ARKit na iOS nie jest to stabilnie zakotwiczone menu w rzeczywistym pokoju.
